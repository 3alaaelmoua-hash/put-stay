(() => {
  "use strict";

  const GOAL = 10;
  const STORAGE_KEY = "put-stay-demo-v1";
  const PIN_KEY = "put-stay-manager-pin-v1";
  const DEMO_PIN = "1234";
  const appContent = document.getElementById("app-content");
  const modal = document.getElementById("app-modal");
  const overlay = document.getElementById("app-overlay");
  const toast = document.getElementById("toast");
  const languageSelect = document.getElementById("language-select");
  let activeView = "";
  let activeTab = "customers";
  let currentCustomerId = "";
  let scannerStream = null;
  let toastTimer = 0;
  let data = loadData();

  const translations = {
    en: {
      navPacks:"Our packs",navHow:"How it works",navContact:"Contact",languageLabel:"Choose language",managerLogin:"Manager login",heroEyebrow:"THE SMARTER WAY TO SAY “SEE YOU SOON”",heroTitle:'Make every visit<br>worth coming <span class="text-green">back for.</span>',heroDescription:"Tap into loyalty that feels personal. One little NFC card, more regulars, happier customers.",explorePacks:"Explore our packs",seeHow:"See how it works",trustLine:"Made for the neighbourhood favourites.",repeatVisits:"Repeat visits",madeRewarding:"made rewarding",loyaltyPass:"YOUR LOYALTY PASS",rewardUnlocked:"Reward unlocked!",customerIsSmiling:"Your customer is smiling.",tapLove:"A little tap. A lot more love.",builtFor:"BUILT FOR YOUR EVERYDAY FAVOURITES",cafes:"Cafés",beauty:"Beauty",retail:"Retail",andMore:"And more",simpleStarts:"A SIMPLE START, A SMARTER RETURN",packsTitle:'Pick your kind of <span class="text-green">good.</span>',packsDescription:"Thoughtful little tools that keep your business top of mind.",packOneKicker:"FOR THE REGULARS",packOneName:"Loyalty<br>Starter",packOneDescription:"Give every visit a little extra meaning.",packOneFeature1:"Digital points card & QR",packOneFeature2:"Rewards when they hit the goal",packOneFeature3:"Customer complaints inbox",packTwoKicker:"FOR THE WORD-OF-MOUTH",packTwoName:"Get<br>Connected",packTwoDescription:"Make it easy to love you, and tell a friend.",packTwoFeature1:"Google reviews link",packTwoFeature2:"Your social accounts",packTwoFeature3:"Complaints & direct phone contact",packThreeKicker:"THE WHOLE GOOD THING",packThreeName:"The<br>Comeback Kit",packThreeDescription:"All the ways to stay close, for less.",packThreeFeature1:"Everything in both packs",packThreeFeature2:"One simple NFC experience",packThreeFeature3:"Save 50 DH on the bundle",oneTime:"one-time",mostLoved:"MOST LOVED",askAboutPack:"Ask about this pack",priceNote:"One-time pack prices. NFC card setup and any ongoing services can be discussed with us.",howEyebrow:"NO APP. NO FUSS. JUST A TAP.",howTitle:'A familiar feeling,<br>made <span class="text-green">effortless.</span>',howDescription:"Your customers tap, collect, connect — and come back. It’s loyalty that fits into the moment.",tryCustomer:"Try the customer demo",stepOneTitle:"Tap or scan",stepOneText:"A quick tap or QR scan opens your business’s customer page.",stepTwoTitle:"Join in a moment",stepTwoText:"Customers register with their name and phone number — no app to download.",stepThreeTitle:"Earn a reason to return",stepThreeText:"Your manager adds points after each visit. A reward is waiting at the goal.",demoEyebrow:"TAKE A LOOK AROUND",demoTitle:'See it from<br><span class="text-green">both sides.</span>',demoDescription:"A working browser demo with a sample manager and customer, ready for you to explore.",customerDemo:"Customer demo",managerDemo:"Manager demo",demoNote:"Demo PIN: 1234. Change it in the manager dashboard.",customerQr:"Customer sign-up QR",scanToJoin:"Scan to join the loyalty club",openRegistration:"Open registration page",contactEyebrow:"YOUR NEXT REGULAR IS ONE TAP AWAY",contactTitle:'Let’s make good<br>things <span>come around.</span>',contactDescription:"Have a shop in mind? We’d love to help you find your perfect pack.",whatsappUs:"WhatsApp us",footerLine:"Small moments. Lasting loyalty.",customerPage:"Customer page",managerPage:"Manager page",managerAccess:"MANAGER ACCESS",enterPin:"Enter your manager PIN to open the dashboard.",pin:"Manager PIN",unlockManager:"Unlock manager",wrongPin:"That PIN isn’t right. Please try again.",demoManager:"Demo manager",managerDashboard:"Manager dashboard",managerWelcome:"Your loyalty club, all in one place.",customersTab:"Customers",complaintsTab:"Complaints",settingsTab:"Settings",signOut:"Sign out",totalCustomers:"Total customers",pointsAwarded:"Visits / points",openComplaints:"Open complaints",scanQr:"Scan customer QR",startCamera:"Start camera",stopCamera:"Stop camera",cameraUnavailable:"QR camera scanning needs a supported browser and a secure (HTTPS) page. You can enter a customer code below instead.",customerCode:"Customer QR code or ID",findCustomer:"Find customer",customersEmpty:"No customers registered yet.",addPoints:"Add points",points:"points",complaintsEmpty:"No complaints received yet.",noComplaints:"No complaints yet.",changePin:"Change manager PIN",currentPin:"Current PIN",newPin:"New PIN",confirmPin:"Confirm new PIN",savePin:"Save PIN",pinChanged:"Manager PIN updated.",pinMismatch:"The current PIN or confirmation doesn’t match.",pinMin:"The new PIN must be at least 4 characters.",pinHint:"PIN changes are stored in this browser demo only. The manager PIN is not displayed on customer pages.",qrScanFound:"Customer found",customerRegistration:"Join the loyalty club",registerDescription:"Register once to collect points every time you visit.",fullName:"Your name",phoneNumber:"Phone number",registerCustomer:"Create my loyalty card",existingCustomer:"Already a member?",lookUpMyCard:"Look up my card",lookupDescription:"Enter your phone number to see your points and loyalty QR.",viewMyCard:"Show my card",customerCard:"Your loyalty card",goalProgress:"points toward your reward",pointsLeft:"points to your reward",rewardReady:"Your reward is ready!",rewardReadyDescription:"Show this card to the manager to redeem your visit reward.",redeemReward:"Redeem reward",rewardRedeemed:"Reward redeemed — your points are ready to start again.",registerFirst:"Register to create your loyalty card and earn points on every visit.",cardNotFound:"We couldn’t find a card with that phone number. Register to get started.",customerExists:"You already have a card! Your points are shown below.",welcomeCustomer:"Welcome to the loyalty club!",registrationQr:"Your personal QR — show it to the manager after each visit.",complaintTab:"Send feedback",complaintTitle:"How can we help?",complaintDescription:"Share a concern with the manager. Your message is private to the business.",complaintMessage:"Your message",sendComplaint:"Send to the manager",complaintSent:"Thanks — your message is with the manager.",noCustomerForComplaint:"Look up your loyalty card first so the manager can follow up.",demoCustomer:"Demo customer",customerNotFound:"No customer found for that QR code.",awardVisit:"Award points for this visit",pointsToAdd:"Points to add",confirmAward:"Add points",pointsAdded:"Points added to the customer card.",pointsAmountError:"Enter a positive whole number of points.",confirmRedeemManager:"Redeem this customer’s reward?",customerSearch:"Search by name, phone or ID",customerPending:"No visits yet",goalLabel:"Reward goal",pointsLabel:"Points",customerMember:"Loyalty member",close:"Close",cancel:"Cancel",scanStatus:"Point the camera at a customer’s personal QR code.",cameraError:"The camera could not be started. Check browser permissions or use the code field.",loadQrError:"This QR code could not be loaded. Check your internet connection.",complaintResolved:"Mark resolved",complaintOpen:"Open",rewardsIn:"to next reward",scanPermission:"Allow camera access in your browser to scan a customer’s QR code.",settingsDescription:"Change the private PIN used to open this manager dashboard.",siteDemoNotice:"Demo version: data is saved only in this browser. To share customer registrations and points across different devices, connect a backend before going live."
    },
    fr: {
      navPacks:"Nos offres",navHow:"Comment ça marche",navContact:"Contact",languageLabel:"Choisir la langue",managerLogin:"Espace gérant",heroEyebrow:"LA FAÇON MALINE DE DIRE « À BIENTÔT »",heroTitle:'Chaque visite donne envie<br>de <span class="text-green">revenir.</span>',heroDescription:"Une fidélité qui se vit pleinement. Une petite carte NFC, plus d’habitués et des clients ravis.",explorePacks:"Découvrir nos offres",seeHow:"Comment ça marche",trustLine:"Pensé pour les commerces du quartier.",repeatVisits:"Les visites reviennent",madeRewarding:"et ça récompense",loyaltyPass:"VOTRE CARTE FIDÉLITÉ",rewardUnlocked:"Récompense débloquée !",customerIsSmiling:"Votre client est ravi.",tapLove:"Un petit geste, beaucoup d’attachement.",builtFor:"POUR VOS ADRESSES PRÉFÉRÉES",cafes:"Cafés",beauty:"Beauté",retail:"Boutiques",andMore:"Et plus",simpleStarts:"BIEN COMMENCER, C’EST FAIRE REVENIR",packsTitle:'Choisissez votre <span class="text-green">formule.</span>',packsDescription:"Des outils simples pour que vos clients pensent à vous.",packOneKicker:"POUR VOS HABITUÉS",packOneName:"Fidélité<br>Essentielle",packOneDescription:"Donnez un petit plus à chaque visite.",packOneFeature1:"Carte de points numérique et QR",packOneFeature2:"Récompense à l’objectif atteint",packOneFeature3:"Espace de réclamations clients",packTwoKicker:"POUR FAIRE PARLER DE VOUS",packTwoName:"Tout en<br>un lien",packTwoDescription:"Facilitez les avis et le bouche-à-oreille.",packTwoFeature1:"Lien vers vos avis Google",packTwoFeature2:"Vos réseaux sociaux",packTwoFeature3:"Réclamations et contact téléphonique",packThreeKicker:"LE MEILLEUR DES DEUX",packThreeName:"Le Pack<br>Complet",packThreeDescription:"Tous les liens utiles, à prix réduit.",packThreeFeature1:"Tout le contenu des deux offres",packThreeFeature2:"Une seule expérience NFC",packThreeFeature3:"50 DH de réduction sur le pack",oneTime:"une seule fois",mostLoved:"LE PLUS CHOISI",askAboutPack:"Découvrir cette offre",priceNote:"Prix des packs en paiement unique. Parlons ensemble de la carte NFC et d’éventuels services complémentaires.",howEyebrow:"SANS APPLI. SANS COMPLICATION. UN GESTE.",howTitle:'Une expérience simple,<br>et vraiment <span class="text-green">fluide.</span>',howDescription:"Un geste, des points, un lien — et l’envie de revenir. La fidélité au bon moment.",tryCustomer:"Tester l’espace client",stepOneTitle:"Touchez ou scannez",stepOneText:"Une carte NFC ou un QR code ouvre la page client de votre commerce.",stepTwoTitle:"Inscription en un instant",stepTwoText:"Le client indique son nom et son numéro, sans télécharger d’application.",stepThreeTitle:"Une raison de revenir",stepThreeText:"Le gérant attribue des points à chaque visite. La récompense attend l’objectif.",demoEyebrow:"FAITES UN TOUR",demoTitle:'Découvrez les deux<br><span class="text-green">expériences.</span>',demoDescription:"Un exemple interactif avec un gérant et un client, à découvrir dès maintenant.",customerDemo:"Démo client",managerDemo:"Démo gérant",demoNote:"Code démo : 1234. Modifiable dans l’espace gérant.",customerQr:"QR d’inscription client",scanToJoin:"Scannez pour rejoindre le programme",openRegistration:"Ouvrir l’inscription",contactEyebrow:"UN PETIT GESTE POUR UN NOUVEL HABITUÉ",contactTitle:'Faisons revenir<br>les <span>belles choses.</span>',contactDescription:"Un commerce en tête ? Parlons de l’offre qui vous correspond.",whatsappUs:"Écrivez-nous sur WhatsApp",footerLine:"De beaux moments, une fidélité durable.",customerPage:"Espace client",managerPage:"Espace gérant",managerAccess:"ACCÈS GÉRANT",enterPin:"Saisissez le code gérant pour ouvrir le tableau de bord.",pin:"Code gérant",unlockManager:"Accéder au tableau",wrongPin:"Code incorrect. Veuillez réessayer.",demoManager:"Gérant démo",managerDashboard:"Tableau de bord gérant",managerWelcome:"Votre programme fidélité en un coup d’œil.",customersTab:"Clients",complaintsTab:"Réclamations",settingsTab:"Paramètres",signOut:"Déconnexion",totalCustomers:"Nombre de clients",pointsAwarded:"Points attribués",openComplaints:"Réclamations à traiter",scanQr:"Scanner le QR client",startCamera:"Démarrer la caméra",stopCamera:"Arrêter la caméra",cameraUnavailable:"Le scan caméra nécessite un navigateur compatible et une page sécurisée (HTTPS). Vous pouvez saisir le code client ci-dessous.",customerCode:"Code QR ou identifiant client",findCustomer:"Rechercher le client",customersEmpty:"Aucun client inscrit.",addPoints:"Ajouter des points",points:"points",complaintsEmpty:"Aucune réclamation reçue.",noComplaints:"Aucune réclamation.",changePin:"Modifier le code gérant",currentPin:"Code actuel",newPin:"Nouveau code",confirmPin:"Confirmer le nouveau code",savePin:"Enregistrer le code",pinChanged:"Le code gérant a été modifié.",pinMismatch:"Le code actuel ou sa confirmation est incorrect.",pinMin:"Le nouveau code doit contenir au moins 4 caractères.",pinHint:"Le code est enregistré uniquement dans cette démo sur ce navigateur. Il n’apparaît pas sur la page client.",qrScanFound:"Client trouvé",customerRegistration:"Rejoignez le programme fidélité",registerDescription:"Inscrivez-vous pour cumuler des points à chaque visite.",fullName:"Votre nom",phoneNumber:"Numéro de téléphone",registerCustomer:"Créer ma carte fidélité",existingCustomer:"Déjà inscrit ?",lookUpMyCard:"Retrouver ma carte",lookupDescription:"Saisissez votre numéro pour consulter vos points et votre QR code.",viewMyCard:"Voir ma carte",customerCard:"Votre carte fidélité",goalProgress:"points avant votre récompense",pointsLeft:"points avant votre récompense",rewardReady:"Votre récompense vous attend !",rewardReadyDescription:"Présentez cette carte au gérant pour utiliser votre récompense.",redeemReward:"Utiliser ma récompense",rewardRedeemed:"Récompense utilisée : vos points repartent à zéro.",registerFirst:"Créez votre carte fidélité pour cumuler des points à chaque visite.",cardNotFound:"Aucune carte associée à ce numéro. Inscrivez-vous pour commencer.",customerExists:"Vous avez déjà une carte ! Retrouvez vos points ci-dessous.",welcomeCustomer:"Bienvenue dans le programme fidélité !",registrationQr:"Votre QR personnel : présentez-le au gérant à chaque visite.",complaintTab:"Nous écrire",complaintTitle:"Comment pouvons-nous vous aider ?",complaintDescription:"Transmettez un message au gérant. Il restera privé.",complaintMessage:"Votre message",sendComplaint:"Envoyer au gérant",complaintSent:"Merci, votre message a été transmis au gérant.",noCustomerForComplaint:"Retrouvez d’abord votre carte pour que le gérant puisse vous répondre.",demoCustomer:"Cliente démo",customerNotFound:"Aucun client associé à ce QR code.",awardVisit:"Attribuer des points pour cette visite",pointsToAdd:"Points à attribuer",confirmAward:"Ajouter les points",pointsAdded:"Les points ont été ajoutés à la carte.",pointsAmountError:"Saisissez un nombre entier de points supérieur à zéro.",confirmRedeemManager:"Utiliser la récompense de ce client ?",customerSearch:"Rechercher par nom, téléphone ou identifiant",customerPending:"Aucune visite",goalLabel:"Objectif récompense",pointsLabel:"Points",customerMember:"Membre fidélité",close:"Fermer",cancel:"Annuler",scanStatus:"Présentez la caméra devant le QR personnel du client.",cameraError:"Impossible de démarrer la caméra. Vérifiez les autorisations ou saisissez le code.",loadQrError:"Impossible de charger ce QR code. Vérifiez votre connexion Internet.",complaintResolved:"Marquer comme traitée",complaintOpen:"À traiter",rewardsIn:"avant la prochaine récompense",scanPermission:"Autorisez l’accès à la caméra pour scanner le QR code du client.",settingsDescription:"Modifiez le code privé permettant d’accéder à ce tableau de bord.",siteDemoNotice:"Démo : les données sont enregistrées uniquement sur ce navigateur. Pour partager les inscriptions et les points entre plusieurs appareils, connectez une base de données avant la mise en ligne."
    },
    ary: {
      navPacks:"الباقات ديالنا",navHow:"كيفاش خدام",navContact:"تاصل بينا",languageLabel:"اختار اللغة",managerLogin:"دخول المسير",heroEyebrow:"الطريقة الزوينة باش تقولو «نشوفوك قريب»",heroTitle:'كل زيارة تخلي الزبون<br><span class="text-green">يبغي يرجع.</span>',heroDescription:"وفاء فيه لمسة شخصية. كارت NFC صغيرة، زبناء ديما راجعين وفرحانين.",explorePacks:"شوف الباقات ديالنا",seeHow:"كيفاش خدام",trustLine:"مصاوب للمحلات لي قراب لينا.",repeatVisits:"زيارات متكررة",madeRewarding:"وكلها مكافآت",loyaltyPass:"كارت الوفاء ديالك",rewardUnlocked:"الهدية ولات واجدة!",customerIsSmiling:"الزبون فرحان.",tapLove:"لمسة صغيرة، محبة كبيرة.",builtFor:"مصاوب للمحلات المفضلة ديالكم",cafes:"قهاوي",beauty:"جمال",retail:"محلات",andMore:"والمزيد",simpleStarts:"بداية بسيطة باش الزبون يرجع",packsTitle:'اختار الباقة <span class="text-green">اللي تناسبك.</span>',packsDescription:"وسائل بسيطة تخلي المحل ديالك ديما فبال الزبون.",packOneKicker:"للزبناء الدائمين",packOneName:"باقة<br>الوفاء",packOneDescription:"عطي لكل زيارة قيمة زيادة.",packOneFeature1:"كارت النقط و QR رقمي",packOneFeature2:"هدية ملي يوصل للهدف",packOneFeature3:"صندوق شكايات الزبناء",packTwoKicker:"باش الناس يهضرو عليك",packTwoName:"باقة<br>التواصل",packTwoDescription:"سهل على الزبون يعجبو المحل ويشارك تجربتو.",packTwoFeature1:"رابط تقييم Google",packTwoFeature2:"حسابات التواصل الاجتماعي",packTwoFeature3:"الشكايات ورقم الهاتف",packThreeKicker:"كلشي مجموع",packThreeName:"باقة<br>الرجوع",packThreeDescription:"جميع المزايا بثمن ناقص.",packThreeFeature1:"جميع مزايا الباقتين",packThreeFeature2:"تجربة NFC وحدة وساهلة",packThreeFeature3:"وفر 50 درهم فالباقة",oneTime:"مرة وحدة",mostLoved:"المفضلة",askAboutPack:"سولنا على هاد الباقة",priceNote:"الثمن ديال الباقات مرة وحدة. نقدروا نهضرو على إعداد كارت NFC والخدمات الإضافية.",howEyebrow:"بلا تطبيق، بلا صداع، غير لمسة.",howTitle:'تجربة مألوفة،<br>سهلة <span class="text-green">وبسيطة.</span>',howDescription:"الزبون كيدير لمسة، كيجمع النقط، كيتواصل — وكيرجع. الوفاء فالو قت المناسب.",tryCustomer:"جرب نسخة الزبون",stepOneTitle:"لمس ولا سكانا",stepOneText:"لمسة NFC ولا QR كتحل صفحة الزبون ديال المحل.",stepTwoTitle:"تسجيل فدقيقة",stepTwoText:"الزبون كيسجل السمية ورقم التلفون، بلا ما يحمل شي تطبيق.",stepThreeTitle:"سبب باش يرجع",stepThreeText:"المسير كيزيد النقط مع كل زيارة، والهدية كتسناه ملي يوصل للهدف.",demoEyebrow:"دير دورة وشوف",demoTitle:'شوف التجربة<br>من <span class="text-green">الجوج ديال الجهات.</span>',demoDescription:"نسخة تجريبية خدامة فيها مسير وزبون، تقدر تكتاشفها دابا.",customerDemo:"تجربة الزبون",managerDemo:"تجربة المسير",demoNote:"الرمز التجريبي: 1234. تقدر تبدلو من لوحة المسير.",customerQr:"QR ديال التسجيل",scanToJoin:"سكانيو باش تنضمو للنقط",openRegistration:"حل صفحة التسجيل",contactEyebrow:"لمسة وحدة وتكسب زبون جديد",contactTitle:'خليو الحوايج الزوينة<br><span>تعاود وترجع.</span>',contactDescription:"عندك محل فبالك؟ نعاونوك تختار الباقة المناسبة ليك.",whatsappUs:"تاصل بينا فالواتساب",footerLine:"لحظات زوينة، ووفاء كيدوم.",customerPage:"صفحة الزبون",managerPage:"صفحة المسير",managerAccess:"دخول المسير",enterPin:"دخل الرمز السري ديال المسير باش تحل لوحة التحكم.",pin:"الرمز السري",unlockManager:"دخول للوحة",wrongPin:"الرمز ماشي صحيح. عاود جرب.",demoManager:"مسير تجريبي",managerDashboard:"لوحة تحكم المسير",managerWelcome:"برنامج الوفاء ديالك كامل هنا.",customersTab:"الزبناء",complaintsTab:"الشكايات",settingsTab:"الإعدادات",signOut:"خرج",totalCustomers:"مجموع الزبناء",pointsAwarded:"النقط لي تزادو",openComplaints:"شكايات مفتوحة",scanQr:"سكانا QR ديال الزبون",startCamera:"شعل الكاميرا",stopCamera:"طفي الكاميرا",cameraUnavailable:"السكانا بالكاميرا خاصها متصفح مناسب وصفحة آمنة (HTTPS). تقدر تدخل كود الزبون هنا.",customerCode:"QR ولا كود الزبون",findCustomer:"قلب على الزبون",customersEmpty:"باقي ما تسجل حتى زبون.",addPoints:"زيد النقط",points:"نقط",complaintsEmpty:"ماوصلات حتى شكاية.",noComplaints:"ماكايناش شكاية.",changePin:"بدل الرمز السري",currentPin:"الرمز الحالي",newPin:"الرمز الجديد",confirmPin:"أكد الرمز الجديد",savePin:"حفظ الرمز",pinChanged:"تبدل الرمز السري.",pinMismatch:"الرمز الحالي ولا التأكيد ماشي صحيح.",pinMin:"الرمز الجديد خاصو يكون فيه 4 حروف على الأقل.",pinHint:"الرمز كيتحفظ غير فهاد المتصفح التجريبي، وما كيبانش فصفحة الزبون.",qrScanFound:"لقينا الزبون",customerRegistration:"انضم لبرنامج الوفاء",registerDescription:"سجل مرة وحدة وجمع النقط مع كل زيارة.",fullName:"السمية الكاملة",phoneNumber:"رقم التلفون",registerCustomer:"صاوب كارت الوفاء ديالي",existingCustomer:"راك مسجل من قبل؟",lookUpMyCard:"قلب على الكارت ديالي",lookupDescription:"دخل رقم التلفون باش تشوف النقط و QR ديالك.",viewMyCard:"شوف الكارت ديالي",customerCard:"كارت الوفاء ديالك",goalProgress:"نقط باش توصل للهدية",pointsLeft:"نقط باقية على الهدية",rewardReady:"الهدية ديالك واجدة!",rewardReadyDescription:"وري هاد الكارت للمسير باش تاخد الهدية.",redeemReward:"خد الهدية",rewardRedeemed:"خديتي الهدية، ورجعات النقط من اللول.",registerFirst:"صاوب كارت الوفاء ديالك باش تبدا تجمع النقط.",cardNotFound:"ما لقيناش كارت بهاد الرقم. سجل باش تبدا.",customerExists:"راك عندك كارت ديجا! النقط ديالك باينين لتحت.",welcomeCustomer:"مرحبا بيك فبرنامج الوفاء!",registrationQr:"QR ديالك: وريه للمسير مع كل زيارة.",complaintTab:"صيفط ملاحظة",complaintTitle:"كيفاش نعاونوك؟",complaintDescription:"صيفط ملاحظة للمسير. غتبقى غير عند المحل.",complaintMessage:"الرسالة ديالك",sendComplaint:"صيفط للمسير",complaintSent:"شكرا، وصلات الرسالة ديالك للمسير.",noCustomerForComplaint:"قلب على كارت الوفاء ديالك باش المسير يقدر يجاوبك.",demoCustomer:"زبونة تجريبية",customerNotFound:"ما لقيناش زبون بهاد QR.",awardVisit:"زيد نقط لهاد الزيارة",pointsToAdd:"شحال من نقطة تزيد",confirmAward:"أكد زيادة النقط",pointsAdded:"تزادو النقط فكارت الزبون.",pointsAmountError:"دخل عدد صحيح من النقط أكبر من صفر.",confirmRedeemManager:"واش باغي تصرف الهدية ديال هاد الزبون؟",customerSearch:"قلب بالسمية ولا التلفون ولا الكود",customerPending:"مازال ماكان حتى زيارة",goalLabel:"الهدف ديال الهدية",pointsLabel:"النقط",customerMember:"عضو فالوفاء",close:"سد",cancel:"إلغاء",scanStatus:"وجه الكاميرا ل QR ديال الزبون.",cameraError:"ماقدرناش نشعلو الكاميرا. تأكد من الصلاحيات ولا دخل الكود.",loadQrError:"ماقدرناش نحملو QR. تأكد من الإنترنت.",complaintResolved:"علمها تحلات",complaintOpen:"مفتوحة",rewardsIn:"باقي للهدية الجاية",scanPermission:"سمح للكاميرا باش تسكانا QR ديال الزبون.",siteDemoNotice:"نسخة تجريبية: البيانات كتتحفظ غير فهاد المتصفح. باش يتشاركو التسجيل والنقط بين أجهزة مختلفة، خاص ربط قاعدة بيانات قبل النشر."
    }
  };

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({
      "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
    })[char]);
  }

  function defaultData() {
    return {
      customers: [{
        id:"PS-DEMO-001",name:"Samira Demo",phone:"0600000000",points:6,
        createdAt:new Date().toISOString(),isDemo:true
      }],
      complaints:[]
    };
  }

  function loadData() {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      const initial = defaultData();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
      return initial;
    }
    const parsed = JSON.parse(stored);
    if (!parsed || !Array.isArray(parsed.customers) || !Array.isArray(parsed.complaints)) {
      throw new Error("Stored Put & Stay demo data has an unexpected format.");
    }
    return parsed;
  }

  function saveData() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }

  function t(key) {
    const language = languageSelect.value in translations ? languageSelect.value : "en";
    return translations[language][key] || translations.en[key] || key;
  }

  function setLanguage(language) {
    languageSelect.value = language in translations ? language : "en";
    const lang = languageSelect.value;
    document.documentElement.lang = lang === "ary" ? "ar-MA" : lang;
    document.documentElement.dir = lang === "ary" ? "rtl" : "ltr";
    document.body.classList.toggle("rtl", lang === "ary");
    document.querySelectorAll("[data-i18n]").forEach(element => {
      const value = translations[lang][element.dataset.i18n];
      if (value) element.innerHTML = value;
    });
    renderSignupQr();
    if (activeView === "manager") showManager();
    else if (activeView === "customer") showCustomer();
  }

  function baseUrl() {
    return `${window.location.origin}${window.location.pathname}`;
  }

  function drawQr(container, value, size, label) {
    container.replaceChildren();
    container.setAttribute("role", "img");
    container.setAttribute("aria-label", label);
    new QRCode(container, {
      text:value,
      width:size,
      height:size,
      colorDark:"#18332c",
      colorLight:"#ffffff",
      correctLevel:QRCode.CorrectLevel.M
    });
  }

  function renderSignupQr() {
    const container = document.getElementById("signup-qr");
    const url = document.getElementById("signup-url");
    const link = `${baseUrl()}#customer`;
    if (container) drawQr(container, link, 156, t("customerQr"));
    if (url) url.textContent = link;
  }

  function openModal(content, view) {
    stopScanner();
    activeView = view;
    appContent.innerHTML = content;
    modal.hidden = false;
    overlay.hidden = false;
    document.body.style.overflow = "hidden";
    modal.scrollTop = 0;
  }

  function closeModal() {
    stopScanner();
    modal.hidden = true;
    overlay.hidden = true;
    appContent.innerHTML = "";
    document.body.style.overflow = "";
    activeView = "";
    currentCustomerId = "";
    if (window.location.hash === "#manager" || window.location.hash === "#customer") {
      history.replaceState(null, "", `${window.location.pathname}${window.location.search}#home`);
    }
  }

  function showToast(message) {
    window.clearTimeout(toastTimer);
    toast.textContent = message;
    toast.classList.add("visible");
    toastTimer = window.setTimeout(() => toast.classList.remove("visible"), 2800);
  }

  function showCustomer() {
    const params = new URLSearchParams(window.location.hash.split("?")[1] || "");
    const customerId = params.get("id");
    if (customerId) {
      const customer = data.customers.find(item => item.id === customerId || item.id === customerId.replace(/^PUTSTAY:/, ""));
      if (customer) {
        currentCustomerId = customer.id;
        renderCustomer(customer.id);
        return;
      }
    }
    currentCustomerId = "";
    renderCustomer(null);
  }

  function customerForm() {
    return `<p class="view-eyebrow">${t("customerMember")}</p>
      <h2 class="view-title" id="modal-title">${t("customerRegistration")}</h2>
      <p class="view-subtitle">${t("registerDescription")}</p>
      <div class="tab-row"><button class="tab-button active" id="register-tab">${t("customerRegistration")}</button><button class="tab-button" id="lookup-tab">${t("lookUpMyCard")}</button></div>
      <form id="register-form"><div class="form-grid">
        <div class="form-field full"><label for="customer-name">${t("fullName")}</label><input id="customer-name" name="name" autocomplete="name" required maxlength="80"></div>
        <div class="form-field full"><label for="customer-phone">${t("phoneNumber")}</label><input id="customer-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" required maxlength="24"></div>
      </div><button class="button button-primary" type="submit">${t("registerCustomer")} <span>↗</span></button></form>
      <p class="info-message">${t("siteDemoNotice")}</p>`;
  }

  function lookupForm() {
    return `<p class="view-eyebrow">${t("customerMember")}</p>
      <h2 class="view-title" id="modal-title">${t("lookUpMyCard")}</h2>
      <p class="view-subtitle">${t("lookupDescription")}</p>
      <form id="lookup-form"><div class="form-field"><label for="lookup-phone">${t("phoneNumber")}</label><input id="lookup-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" required maxlength="24"></div><div class="form-actions"><button class="button button-primary" type="submit">${t("viewMyCard")} <span>↗</span></button><button class="button button-outline" type="button" id="back-register">${t("customerRegistration")}</button></div></form>
      <p class="info-message">${t("siteDemoNotice")}</p>`;
  }

  function renderCustomer(customerId) {
    currentCustomerId = customerId || "";
    const customer = customerId ? data.customers.find(item => item.id === customerId) : null;
    if (!customer) {
      openModal(customerForm(), "customer");
      wireCustomerForms();
      return;
    }
    const balance = Math.max(0, Number(customer.points) || 0);
    const remaining = Math.max(0, GOAL - balance);
    const progress = Math.min(100, balance / GOAL * 100);
    const qrValue = `PUTSTAY:${customer.id}`;
    const reward = balance >= GOAL;
    openModal(`<p class="view-eyebrow">${t("customerCard")}</p><h2 class="view-title" id="modal-title">${escapeHtml(customer.name)}</h2>
      <p class="view-subtitle">${t("registrationQr")}</p>
      ${customer.isDemo ? `<p class="info-message">${t("demoCustomer")}</p>` : ""}
      <div class="customer-card-grid"><div><div class="pass-card"><div class="pass-card-top"><span>put&amp;stay</span><span>${t("goalLabel")}: ${GOAL}</span></div><p class="pass-card-name">${escapeHtml(customer.name)}</p><div class="pass-points"><strong>${balance}</strong> / ${GOAL} ${t("pointsLabel")}</div><div class="progress-track"><div class="progress-fill" style="width:${progress}%"></div></div><div class="pass-card-bottom"><span>${reward ? t("rewardReady") : `${remaining} ${t("pointsLeft")}`}</span><span>${escapeHtml(customer.phone)}</span></div></div>
      <p class="${reward ? "success-message" : "view-subtitle"}">${reward ? t("rewardReadyDescription") : `${balance} ${t("goalProgress")}`}</p>
      ${reward ? `<button class="button button-primary" type="button" id="customer-redeem">${t("redeemReward")}</button>` : ""}
      </div><div><div class="customer-qr generated-qr" id="personal-qr"></div><p class="customer-qr-caption">${escapeHtml(customer.id)}</p></div></div>
      <div class="tab-row"><button class="tab-button active" id="card-tab">${t("customerCard")}</button><button class="tab-button" id="complaint-tab">${t("complaintTab")}</button></div>
      <div id="customer-tab-content"></div>`, "customer");
    drawQr(document.getElementById("personal-qr"), qrValue, 140, t("registrationQr"));
    document.getElementById("customer-tab-content").innerHTML = `<p class="form-help">${t("goalProgress")}: ${balance}/${GOAL}. ${t("pointsLeft")}: ${remaining}.</p>`;
    document.getElementById("card-tab").addEventListener("click", () => {
      document.getElementById("card-tab").classList.add("active");
      document.getElementById("complaint-tab").classList.remove("active");
      document.getElementById("customer-tab-content").innerHTML = `<p class="form-help">${balance} ${t("goalProgress")}. ${t("pointsLeft")}: ${remaining}.</p>`;
    });
    document.getElementById("complaint-tab").addEventListener("click", () => {
      document.getElementById("complaint-tab").classList.add("active");
      document.getElementById("card-tab").classList.remove("active");
      document.getElementById("customer-tab-content").innerHTML = `<p class="view-subtitle">${t("complaintDescription")}</p><form id="complaint-form"><div class="form-field"><label for="complaint-message">${t("complaintMessage")}</label><textarea id="complaint-message" required maxlength="2000"></textarea></div><button class="button button-primary" type="submit">${t("sendComplaint")}</button></form>`;
      document.getElementById("complaint-form").addEventListener("submit", event => {
        event.preventDefault();
        const message = document.getElementById("complaint-message").value.trim();
        if (!message) return;
        data.complaints.unshift({id:crypto.randomUUID(),customerId:customer.id,name:customer.name,phone:customer.phone,message,createdAt:new Date().toISOString(),resolved:false});
        saveData();
        renderCustomer(customer.id);
        showToast(t("complaintSent"));
      });
    });
    const redeem = document.getElementById("customer-redeem");
    if (redeem) redeem.addEventListener("click", () => redeemReward(customer.id));
  }

  function wireCustomerForms() {
    document.getElementById("register-tab").addEventListener("click", () => renderCustomer(null));
    document.getElementById("lookup-tab").addEventListener("click", () => {
      appContent.innerHTML = lookupForm();
      wireLookupForm();
    });
    document.getElementById("register-form").addEventListener("submit", event => {
      event.preventDefault();
      const name = document.getElementById("customer-name").value.trim();
      const phone = normalizePhone(document.getElementById("customer-phone").value);
      if (name.length < 2 || phone.length < 7) {
        showToast(t("cardNotFound"));
        return;
      }
      const existing = data.customers.find(item => normalizePhone(item.phone) === phone);
      if (existing) {
        renderCustomer(existing.id);
        showToast(t("customerExists"));
        return;
      }
      const customer = {id:`PS-${crypto.randomUUID().slice(0,8).toUpperCase()}`,name,phone,points:0,createdAt:new Date().toISOString()};
      data.customers.unshift(customer);
      saveData();
      renderCustomer(customer.id);
      showToast(t("welcomeCustomer"));
    });
  }

  function wireLookupForm() {
    document.getElementById("back-register").addEventListener("click", () => renderCustomer(null));
    document.getElementById("lookup-form").addEventListener("submit", event => {
      event.preventDefault();
      const phone = normalizePhone(document.getElementById("lookup-phone").value);
      const customer = data.customers.find(item => normalizePhone(item.phone) === phone);
      if (!customer) {
        showToast(t("cardNotFound"));
        return;
      }
      renderCustomer(customer.id);
    });
  }

  function normalizePhone(value) {
    return value.replace(/\D/g, "").replace(/^212/, "0");
  }

  function showManager() {
    if (sessionStorage.getItem("put-stay-manager-auth") === "yes") {
      renderManager();
      return;
    }
    openModal(`<p class="view-eyebrow">${t("managerAccess")}</p><h2 class="view-title" id="modal-title">${t("managerLogin")}</h2><p class="view-subtitle">${t("enterPin")}</p>
      <form id="pin-form"><div class="form-field"><label for="manager-pin">${t("pin")}</label><input id="manager-pin" type="password" inputmode="numeric" autocomplete="current-password" required autofocus></div><button class="button button-primary" type="submit">${t("unlockManager")} <span>↗</span></button></form>`, "manager");
    document.getElementById("pin-form").addEventListener("submit", event => {
      event.preventDefault();
      const currentPin = localStorage.getItem(PIN_KEY) || DEMO_PIN;
      if (document.getElementById("manager-pin").value !== currentPin) {
        showToast(t("wrongPin"));
        document.getElementById("manager-pin").value = "";
        document.getElementById("manager-pin").focus();
        return;
      }
      sessionStorage.setItem("put-stay-manager-auth", "yes");
      renderManager();
    });
  }

  function renderManager() {
    const customerCount = data.customers.length;
    const awarded = data.customers.reduce((sum, customer) => sum + (Number(customer.points) || 0), 0);
    const openCount = data.complaints.filter(complaint => !complaint.resolved).length;
    openModal(`<div class="manager-topbar"><div><p class="view-eyebrow">${t("demoManager")}</p><h2 class="view-title" id="modal-title">${t("managerDashboard")}</h2></div><button class="button button-outline button-tiny" id="manager-signout">${t("signOut")}</button></div><p class="view-subtitle">${t("managerWelcome")}</p>
      <div class="stat-grid"><div class="stat-card"><strong>${customerCount}</strong><span>${t("totalCustomers")}</span></div><div class="stat-card"><strong>${awarded}</strong><span>${t("pointsAwarded")}</span></div><div class="stat-card"><strong>${openCount}</strong><span>${t("openComplaints")}</span></div></div>
      <div class="tab-row"><button class="tab-button ${activeTab === "customers" ? "active" : ""}" id="customers-tab">${t("customersTab")}</button><button class="tab-button ${activeTab === "complaints" ? "active" : ""}" id="complaints-tab">${t("complaintsTab")}${openCount ? ` (${openCount})` : ""}</button><button class="tab-button ${activeTab === "settings" ? "active" : ""}" id="settings-tab">${t("settingsTab")}</button></div>
      <div id="manager-tab-content"></div><p class="security-note">${t("siteDemoNotice")}</p>`, "manager");
    document.getElementById("manager-signout").addEventListener("click", () => {
      sessionStorage.removeItem("put-stay-manager-auth");
      showManager();
    });
    document.getElementById("customers-tab").addEventListener("click", () => { activeTab = "customers"; renderManager(); });
    document.getElementById("complaints-tab").addEventListener("click", () => { activeTab = "complaints"; renderManager(); });
    document.getElementById("settings-tab").addEventListener("click", () => { activeTab = "settings"; renderManager(); });
    const content = document.getElementById("manager-tab-content");
    if (activeTab === "customers") renderCustomerManagerTab(content);
    else if (activeTab === "complaints") renderComplaintManagerTab(content);
    else renderSettingsManagerTab(content);
  }

  function renderCustomerManagerTab(container) {
    container.innerHTML = `<div class="scanner-area"><strong class="form-help">${t("scanQr")}</strong><p class="scanner-status">${t("scanStatus")}</p><div class="form-actions"><button class="button button-primary button-tiny" type="button" id="start-camera">${t("startCamera")}</button></div><video id="scanner-video" playsinline hidden></video><form class="form-grid" id="scan-code-form"><div class="form-field full"><label for="scan-code">${t("customerCode")}</label><input id="scan-code" placeholder="PS-XXXXXXXX or PUTSTAY:..."></div><button class="button button-outline button-tiny" type="submit">${t("findCustomer")}</button></form></div>
      <div class="form-field"><label for="customer-search">${t("customerSearch")}</label><input id="customer-search" type="search" autocomplete="off"></div><div class="customer-list" id="customer-list"></div>`;
    renderCustomerList();
    document.getElementById("customer-search").addEventListener("input", renderCustomerList);
    document.getElementById("scan-code-form").addEventListener("submit", event => {
      event.preventDefault();
      openScannedCustomer(document.getElementById("scan-code").value);
    });
    document.getElementById("start-camera").addEventListener("click", () => {
      if (scannerStream) stopScanner();
      else startScanner();
    });
  }

  function renderCustomerList() {
    const list = document.getElementById("customer-list");
    if (!list) return;
    const query = (document.getElementById("customer-search")?.value || "").trim().toLowerCase();
    const customers = data.customers.filter(customer => `${customer.name} ${customer.phone} ${customer.id}`.toLowerCase().includes(query));
    if (!customers.length) {
      list.innerHTML = `<div class="empty-state">${t("customersEmpty")}</div>`;
      return;
    }
    list.innerHTML = customers.map(customer => `<article class="customer-row"><div><strong>${escapeHtml(customer.name)}${customer.isDemo ? ` · ${t("demoCustomer")}` : ""}</strong><small>${escapeHtml(customer.phone)} · ${escapeHtml(customer.id)}</small></div><div class="row-actions"><span class="row-points">${Number(customer.points) || 0}/${GOAL} ${t("pointsLabel")}</span><button class="button button-primary button-tiny" type="button" data-customer-id="${escapeHtml(customer.id)}">${t("addPoints")}</button></div></article>`).join("");
    list.querySelectorAll("[data-customer-id]").forEach(button => button.addEventListener("click", () => showAwardForm(button.dataset.customerId)));
  }

  function renderComplaintManagerTab(container) {
    if (!data.complaints.length) {
      container.innerHTML = `<div class="empty-state">${t("complaintsEmpty")}</div>`;
      return;
    }
    container.innerHTML = data.complaints.map(complaint => `<article class="complaint-row"><strong>${escapeHtml(complaint.name)} · ${escapeHtml(complaint.phone)}</strong><small>${new Date(complaint.createdAt).toLocaleString()} · ${complaint.resolved ? t("complaintResolved") : t("complaintOpen")}</small><p>${escapeHtml(complaint.message)}</p>${complaint.resolved ? "" : `<button class="button button-outline button-tiny" type="button" data-complaint-id="${escapeHtml(complaint.id)}">${t("complaintResolved")}</button>`}</article>`).join("");
    container.querySelectorAll("[data-complaint-id]").forEach(button => button.addEventListener("click", () => {
      const complaint = data.complaints.find(item => item.id === button.dataset.complaintId);
      if (complaint) complaint.resolved = true;
      saveData();
      renderManager();
    }));
  }

  function renderSettingsManagerTab(container) {
    container.innerHTML = `<p class="view-subtitle">${t("settingsDescription")}</p><form id="change-pin-form"><div class="form-field"><label for="current-pin">${t("currentPin")}</label><input id="current-pin" type="password" autocomplete="current-password" required></div><div class="form-grid"><div class="form-field"><label for="new-pin">${t("newPin")}</label><input id="new-pin" type="password" autocomplete="new-password" minlength="4" required></div><div class="form-field"><label for="confirm-pin">${t("confirmPin")}</label><input id="confirm-pin" type="password" autocomplete="new-password" minlength="4" required></div></div><button class="button button-primary" type="submit">${t("savePin")}</button></form><p class="security-note">${t("pinHint")}</p>`;
    document.getElementById("change-pin-form").addEventListener("submit", event => {
      event.preventDefault();
      const current = document.getElementById("current-pin").value;
      const next = document.getElementById("new-pin").value;
      const confirm = document.getElementById("confirm-pin").value;
      const storedPin = localStorage.getItem(PIN_KEY) || DEMO_PIN;
      if (current !== storedPin || next !== confirm) {
        showToast(t("pinMismatch"));
        return;
      }
      if (next.length < 4) {
        showToast(t("pinMin"));
        return;
      }
      localStorage.setItem(PIN_KEY, next);
      renderManager();
      showToast(t("pinChanged"));
    });
  }

  function showAwardForm(customerId) {
    const customer = data.customers.find(item => item.id === customerId);
    if (!customer) {
      showToast(t("customerNotFound"));
      renderManager();
      return;
    }
    const existing = document.getElementById("award-dialog");
    if (existing) existing.remove();
    const wrapper = document.createElement("div");
    wrapper.id = "award-dialog";
    wrapper.className = "scanner-area";
    wrapper.innerHTML = `<strong class="form-help">${t("awardVisit")}: ${escapeHtml(customer.name)}</strong><p class="scanner-status">${Number(customer.points) || 0}/${GOAL} ${t("pointsLabel")}</p><form class="form-actions" id="award-form"><input type="number" id="award-points" min="1" step="1" value="1" aria-label="${t("pointsToAdd")}" required><button class="button button-primary button-tiny" type="submit">${t("confirmAward")}</button><button class="button button-outline button-tiny" type="button" id="cancel-award">${t("cancel")}</button></form>`;
    document.getElementById("manager-tab-content").prepend(wrapper);
    document.getElementById("cancel-award").addEventListener("click", () => wrapper.remove());
    document.getElementById("award-form").addEventListener("submit", event => {
      event.preventDefault();
      const amount = Number(document.getElementById("award-points").value);
      if (!Number.isSafeInteger(amount) || amount < 1) {
        showToast(t("pointsAmountError"));
        return;
      }
      customer.points = (Number(customer.points) || 0) + amount;
      saveData();
      renderManager();
      showToast(t("pointsAdded"));
    });
  }

  function redeemReward(customerId) {
    const customer = data.customers.find(item => item.id === customerId);
    if (!customer || Number(customer.points) < GOAL) return;
    customer.points -= GOAL;
    saveData();
    renderCustomer(customer.id);
    showToast(t("rewardRedeemed"));
  }

  function openScannedCustomer(code) {
    const id = code.trim().replace(/^PUTSTAY:/i, "").replace(/^.*[#&]id=/, "");
    const customer = data.customers.find(item => item.id.toLowerCase() === id.toLowerCase());
    if (!customer) {
      showToast(t("customerNotFound"));
      return;
    }
    showAwardForm(customer.id);
    const status = document.querySelector(".scanner-status");
    if (status) status.textContent = `${t("qrScanFound")}: ${customer.name}`;
  }

  async function startScanner() {
    const status = document.querySelector(".scanner-status");
    const video = document.getElementById("scanner-video");
    const button = document.getElementById("start-camera");
    if (!("BarcodeDetector" in window)) {
      if (status) status.textContent = t("cameraUnavailable");
      return;
    }
    try {
      const detector = new BarcodeDetector({formats:["qr_code"]});
      scannerStream = await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"},audio:false});
      video.srcObject = scannerStream;
      video.hidden = false;
      await video.play();
      button.textContent = t("stopCamera");
      if (status) status.textContent = t("scanPermission");
      const scan = async () => {
        if (!scannerStream || activeView !== "manager") return;
        try {
          const codes = await detector.detect(video);
          if (codes.length) {
            const code = codes[0].rawValue;
            stopScanner();
            openScannedCustomer(code);
            return;
          }
        } catch (error) {
          console.error("Could not scan the customer QR code.", error);
          if (status) status.textContent = t("cameraError");
          stopScanner();
          return;
        }
        window.setTimeout(scan, 300);
      };
      scan();
    } catch (error) {
      console.error("Could not start the QR scanner.", error);
      if (status) status.textContent = t("cameraError");
      stopScanner();
    }
  }

  function stopScanner() {
    if (scannerStream) {
      scannerStream.getTracks().forEach(track => track.stop());
      scannerStream = null;
    }
    const video = document.getElementById("scanner-video");
    if (video) {
      video.pause();
      video.srcObject = null;
      video.hidden = true;
    }
    const button = document.getElementById("start-camera");
    if (button) {
      button.textContent = t("startCamera");
    }
  }

  function route() {
    const hash = window.location.hash;
    if (hash.startsWith("#manager")) {
      showManager();
    } else if (hash.startsWith("#customer")) {
      showCustomer();
    } else if (activeView) {
      closeModal();
    }
  }

  languageSelect.addEventListener("change", () => setLanguage(languageSelect.value));
  document.getElementById("modal-close").addEventListener("click", closeModal);
  overlay.addEventListener("click", closeModal);
  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && !modal.hidden) closeModal();
  });
  document.getElementById("menu-toggle").addEventListener("click", event => {
    const nav = document.querySelector(".main-nav");
    const expanded = event.currentTarget.getAttribute("aria-expanded") === "true";
    event.currentTarget.setAttribute("aria-expanded", String(!expanded));
    nav.classList.toggle("open", !expanded);
  });
  document.querySelectorAll(".main-nav a").forEach(link => link.addEventListener("click", () => {
    document.querySelector(".main-nav").classList.remove("open");
    document.getElementById("menu-toggle").setAttribute("aria-expanded", "false");
  }));
  window.addEventListener("hashchange", route);
  document.getElementById("year").textContent = String(new Date().getFullYear());
  setLanguage("en");
  route();
})();
