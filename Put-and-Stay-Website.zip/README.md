# Put & Stay

A responsive, static website demo for NFC loyalty cards, customer registration and the manager dashboard.

## Pages

- `#home` — public business landing page and pack details.
- `#customer` — customer registration, points, personal QR code and private feedback.
- `#manager` — manager dashboard, QR scanner, point awards, feedback inbox and PIN settings.

Select English, French or Moroccan Darija in Arabic script from the language menu.

## Run the demo

Open `index.html` in a browser. QR codes are generated locally in the browser; customer IDs are not sent to a QR-generation service. Camera-based QR scanning requires a supported browser and a secure HTTPS origin; the manager can also enter a customer's QR code or ID.

The initial manager PIN is **1234**. A sample customer, Samira Demo (`0600000000`), starts with 6 of 10 points. Both are demo data and can be changed in the manager dashboard.

## Demo limitations before launch

This is a browser-only demo: customer records, points, complaints and the manager PIN are stored in that browser's local storage. They do **not** synchronize to a manager on a different device, and the PIN is not a secure authentication system. Do not enter real customer information into this demo. A live multi-device service needs a hosted backend, secure manager authentication and a privacy-conscious database.

To make the site available publicly, publish these static files on an HTTPS static host and use the published URL for the customer and manager links and sign-up QR. NFC cards should link to the published `#customer` page.

## Packs

1. Loyalty points, rewards and complaints case — **200 DH**.
2. Google reviews, social media, complaints case and phone contact — **200 DH**.
3. Both packs with a 50 DH bundle discount — **350 DH**.

WhatsApp contact: [0649345370](https://wa.me/212649345370).

The bundled QR encoder is QRCode.js by davidshimjs and is distributed under the MIT License; see [qrcodejs.LICENSE](./qrcodejs.LICENSE).
